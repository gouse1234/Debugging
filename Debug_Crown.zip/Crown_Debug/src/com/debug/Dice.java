package com.debug;

public class Dice {

	
	private DiceValue value;
	
	public Dice() {
		value =  DiceValue.getRandom();
	}
	// after bug resolution
	public DiceValue getValue() {
		value =  DiceValue.getRandom();	
		return value;
	}

	public DiceValue roll() {
		return DiceValue.getRandom();
	}		
	
	public String toString() {
		return value.toString();
	}


}
